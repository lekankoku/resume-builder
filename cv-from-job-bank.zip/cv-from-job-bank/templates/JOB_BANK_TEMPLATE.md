# Candidate Job Bank — optional template

This is a **fact inventory**, not a finished CV. Keep as much detail as possible. Paste rough notes; the skill will select and rewrite relevant parts. You do not need to use this template if you already have a Job Bank.

## Identity and approved public details

- Name:
- City/country:
- Email / phone / LinkedIn / GitHub (only fields to print in the CV):
- Preferred language and target geography:

## Role: [Employer] — [Official title]

- Employment dates (precision as known):
- City / remote:
- Product, domain and team context:
- Responsibilities (what I actually owned):
- Technology actually used **in this role**:
- What shipped to production vs prototype/idea:

### Achievement 1: [Short label]

- Situation / problem:
- My personal action and decisions:
- Tools / architecture / methods:
- Collaborators / responsibility boundaries:
- Result or value (quantitative **only if verified**):
- Number + units + period + denominator / baseline:
- Evidence (ticket, document, release note, report, recollection) and confidence:
- Wording or confidentiality constraints:

### Achievement 2: [Short label]

- Situation / problem:
- My personal action and decisions:
- Tools / architecture / methods:
- Result or value:
- Evidence and confidence:

Repeat role and achievement blocks for every past position and substantive project.

## Education

- Institution:
- Qualification:
- Started / completed / **in progress**:
- Thesis / relevant coursework / distinction (documented):

## Skills and languages

- Programming languages / frameworks / data / infrastructure / testing (distinguish professional, academic, personal):
- Languages (documented or honestly self-assessed level):
- Certifications / licenses and dates:

## Other relevant evidence

- Personal or open-source projects:
- Mentorship, talks, teaching, awards:
- Relevant verified links:

## Open questions and boundaries

- Metrics I might be able to confirm:
- Facts I am uncertain about:
- Claims or confidential topics that must not appear publicly:
