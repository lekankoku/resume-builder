# Output specification and acceptance gates

## Deliverables

For a normal job-specific CV request, produce:

1. `CV_<Candidate>_<Company>_<Role>` in the requested medium if the environment can produce it reliably. Prefer editable `DOCX` plus final `PDF` for styled CVs, or copy-ready Markdown when document tools are unavailable. PDF must be selectable and visually checked.
2. A compact tailoring note covering highest-priority requirements, evidence-backed strengths, legitimate gaps, and a clear `Ready to submit` / `Needs confirmation` label.
3. An evidence audit table in the conversation or, if the user requests it, a separate `CV_Evidence_Audit` file. The audit is not part of the document handed to a recruiter.

If output tools do not support professional document production, do **not** claim a final PDF or DOCX exists. Provide the full copy-ready CV content and describe the export limitation. Never fabricate links.

## CV architecture

**Guide-inspired two-column CV:**

- Header across the page: candidate name, short target-aligned professional identity, contact/location.
- Main section (wider): selected roles with clear dates and high-signal results; education; substantial relevant technical projects; highly relevant other achievements.
- Secondary section (narrower): 4–8 job-related ability titles with concise evidence descriptions; categorized technical tools; language proficiency; optional leadership or certificates.
- Use black, neutral grey and a subtle blue accent, consistent line spacing and alignment. No graphical proficiency meters.

**ATS-first CV:**

- One column in logical reading order: Contact > Headline > Selected Technical Skills / Core Competencies > Professional Experience > Projects if needed > Education > Languages / Certifications.
- Use text headings, conventional bullets, and standard organization/title/date strings. Avoid text boxes and columns that scramble extraction.

Keep underlying claims identical across both. The user can request just one of them.

## 12-point quality gate

Mark `Pass`, `Needs review`, or `Fail` internally for each item. Fix `Fail`s before delivery.

1. Every employer/title/date is supported by the candidate bank or confirmed by the user.
2. Every metric, unit, timeframe and improvement attribution is sourced and accurately worded.
3. Each claimed tool/technology is actually used or otherwise substantiated, not copied from the vacancy.
4. Ownership verbs match the person's role; prototypes, plans and estimates are not presented as delivered results.
5. Top advertised must-haves with supporting evidence are easy to spot; unsupported must-haves are not manufactured.
6. The first 10–15 seconds reveal the right professional identity, strongest role, and strongest relevant capabilities.
7. Most relevant role(s) have the highest information density; older unrelated work does not dominate.
8. Bullets are distinct, concrete, readable, and free of hype and fabricated outcomes.
9. Current or unfinished education and jobs are labelled accurately; no invented months or unexplained timeline edits.
10. Contacts, portrait, location, nationality and reference details include only information authorized for publication.
11. Formatting has correct line breaks, no clipped text, a consistent visual hierarchy, and reliable text extraction when exported.
12. Spelling and technical semantics are correct; key terms are natural, not repeatedly stuffed to chase an invented ATS score.

## Evidence audit table

Use this brief table (up to ~10 most significant rows) to let the user spot-check important claims:

| CV statement / abbreviated bullet | Supporting source | Fidelity | Note |
| --- | --- | --- | --- |
| Added callback request deduplication | Job Bank, Payments project | Direct | No numerical savings claimed |
| Experience with distributed retries | Job Bank, Payments project | Partial | Related experience, no Kafka claim |

Where there are several source files, give filenames and page/section pointers if available. Avoid publishing the user's complete job bank or private contact data in the audit unnecessarily.

## Done definition

The CV is ready only when the essential fields are verified, strong major requirements are represented truthfully, no unsupported claims remain, and the requested output files have actually been created and opened/checked. If any critical point remains disputed, hand over a clearly marked draft instead of falsely claiming it is finished.
