# Guide-derived CV principles (original operational adaptation)

This file distills workflow principles from the candidate-supplied *CV Mastermind Guide*. It is an independent set of instructions for the CV-writing task, **not** a reproduction or redistribution of the paid guide, its examples, or its linked proprietary template.

## The dual audience

The first pass is a very quick relevance scan; later reviewers may inspect details. Optimize the top of page 1 for a coherent role identity, relevant latest or strongest experience, and immediately legible capabilities. Then provide sufficiently specific evidence for technical interviewers and hiring managers.

## Tailoring discipline

1. Analyze the target advertisement before writing.
2. Cluster its required and strongly repeated abilities into 4–8 capability themes.
3. For each theme, identify real examples from the bank and reserve keywords only where truthful.
4. Spend most rewriting effort on the strongest one or two previous roles and the prominent abilities/skills area.
5. Omit genuinely distracting old experience when appropriate, but do not create a misleading chronology or hide a relevant role for convenience.
6. Prefer relevance and specificity over a long exhaustive inventory of everything the candidate has ever done.

## Content hierarchy

**Professional headline:** short, recognizable identity such as `Backend Software Engineer | Kotlin, Java, Event-Driven Systems` **only when every component is supported**. Avoid “passionate, motivated, dynamic...” openings.

**Work experience:** highest-priority proof. A role overview should establish context. Subsequent bullets present meaningful contributions and results. Give more space to proven relevant roles, even when they are not the newest.

**Job-related abilities:** role-specific capability headings with short supporting phrases. Examples of *types*, not candidate claims: `Service Design`, `Data Integrity`, `Event-Driven Integration`, `Cross-Functional Delivery`. Never create an ability category solely because it appears in a job posting.

**Technical expertise:** show credible language/framework/database/cloud/tooling categories, with evidence in the work history wherever possible. For engineers, make substantive projects easy to find in the main content rather than burying them in a narrow sidebar.

**Education:** detail is proportional to career stage. For experienced candidates, degrees and genuinely distinguishing relevant work are enough. For graduates, education, labs, tutoring, thesis, and projects may lead.

**Projects and extracurriculars:** include selectively when they add substantial missing evidence or relevant differentiation. Do not fill space with general hobbies.

**Languages:** factual proficiency levels, not optimistic self-certification. Focus on languages material to the role, particularly English/German in Germany.

**References:** privacy-respecting and optional; only publish contact details with affirmative permission.

## Design stance

- A Germany-oriented editorial layout may use two columns (main experience versus secondary abilities) with restrained colors and readable type.
- A machine-parsed ATS version should use one column and uncomplicated headings.
- A conventional range of 1–3 pages is reasonable depending on seniority and evidence. Aim for concision, not a fixed page count.
- English is the default when the employer accepts it. Use German if the posting requires German or the user requests it. In translation, preserve actual semantics and correct technical vocabulary.
- Photo, full street address, nationality, and other sensitive personal details are **not automatic**. Ask the candidate if one materially affects a requested local format. Never include birth date by default.
- Review the final exported PDF visually and test whether the text is selectable, reads in the correct order, and retains the important keywords.

## Engineering-specific adaptation

- Engineering bullets should name the system or component, the technical action, and its operational/business consequence, while respecting confidentiality.
- Strong real evidence may include concurrency controls, transactional guarantees, resilience patterns, API lifecycle, CI/CD, observability, incidents, cost/performance, and user impact. These are **possible themes**, not things to assert without evidence.
- Be careful with vague “built scalable systems” claims. If the bank contains no throughput, capacity, SLO, or load evidence, describe the actual architecture and design objective without claiming proven scale.
- “Used Spring/Kotlin in a team” does not automatically establish designing architecture, owning the service, or operating Kubernetes.
