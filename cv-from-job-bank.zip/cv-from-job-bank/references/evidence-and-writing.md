# Evidence processing and writing specification

## Normalized bank model

Build this private model from whatever files the candidate provides; never demand that the input conform to it.

```yaml
candidate:
  name: "confirmed name"
  location: "confirmed city/country"
  contact: "approved fields only"
roles:
  - employer: "company"
    official_title: "verified title"
    public_title: "same or accurately clarified"
    location: "city or remote"
    dates: {start: "YYYY-MM or known precision", end: "YYYY-MM, Present or known precision"}
    context: "team/product/domain"
    claims:
      - id: "BANK-COMPANY-01"
        raw_fact: "close paraphrase of documented candidate fact"
        action: "what candidate did"
        technology: ["per-role tech only"]
        scope: "what candidate actually owned/contributed"
        result: "documented effect or null"
        metric: {value: null, unit: null, period: null, status: "unverified|verified|estimate"}
        maturity: "proposal|prototype|shipped|production|unknown"
        source: "file and section/page or user message"
        confidence: "direct|partial|ambiguous"
skills:
  - name: "tool or capability"
    evidence_ids: ["BANK-COMPANY-01"]
education: []
languages: []
unresolved_conflicts: []
```

If a bank contains several variations of an achievement, consolidate **without stacking numbers** or treating two descriptions of the same work as separate wins.

## Classify evidence

- **Direct:** explicit fact in bank; can be published with any necessary qualification.
- **Derived but safe:** modest reformulation that preserves exactly the claim's scope (e.g., “made a checkout service easier to maintain” from well-described refactoring intent, **if** this is documented as an achieved result rather than merely a goal).
- **Partial or adjacent:** legitimate transfer of an underlying concept, not an equivalent technology. For example, a Postgres transaction project supports database consistency but **not** specific experience with DynamoDB.
- **Unknown:** a claim without a candidate source; exclude it and consider asking for clarification.
- **Conflicted:** two incompatible candidate sources; resolve, qualify, or omit.

Specific danger zones: do not promote architecture goals to measured outcomes; team accomplishments to sole ownership; familiarity to production expertise; pilot to company-wide launch; time savings from another team's workflow to personal impact; estimates to measured actuals; and internal performance feedback to externally verified performance claims.

## Requirement mapping

For each top job requirement, record:

1. Exact term from the advertisement.
2. Priority (`must`, `important`, `bonus`).
3. Source handles and proof strength (`direct`, `partial`, `gap`).
4. Allowed CV language.
5. Placement (`experience`, `projects`, `skills`, `abilities`, `omit`).

The CV should lead with the best *verified* overlaps, not mirror every advertised skill. Keyword presence must have a truthful semantic context. Repetition is useful only when a term accurately describes more than one real accomplishment.

## Bullet construction

Write natural, readable bullets using one of these patterns (not rote templates):

- **Outcome first:** `[Verified number or result] by [concrete action] using [supported methods/technology].`
- **Engineering action:** `[Strong verb] [component/process] with [specific design or tools], enabling [documented reason/result].`
- **Ownership and collaboration:** `[Actual role in work] with [team/discipline] to [deliverable] for [user/process].`

Prefer `Developed`, `Refactored`, `Integrated`, `Implemented`, `Designed`, `Tested`, `Operated`, `Investigated`, `Reduced`, `Supported`, `Coordinated` only when corresponding scope is evidenced. Start with the result when that is both impactful and measured. Avoid filler (`responsible for`, `worked on`, `helped with`) unless precision requires it. Avoid falsely precise stats and inflated verbs (`spearheaded`, `revolutionized`, `single-handedly`).

**Length:** generally one or two wrapped lines. Important and complex work can take slightly more. Never trim the clause that explains what the candidate actually did merely to fit a formula. Vary syntax; avoid identical intros repeated across roles.

### An invented demonstration (not candidate history)

**Candidate evidence:** "Added request deduplication to the payment callback handler in Node.js; customer support reported fewer duplicate tickets; no counts available."

**Good:** "Implemented request deduplication in the Node.js payment callback handler to prevent repeated processing on retries."

**Bad:** "Led a payment platform modernization, eliminating 98% of duplicate transactions and saving €1M annually."

The bad version introduces leadership, a platform-scale project, a numeric improvement, and a financial impact that the evidence does not support.

## Editing and fact-preservation rules

- Retain employer and date chronology. Do not invent month precision if only years are known.
- Do not change “proposed” into “implemented,” or “team built” into “I architected.”
- If no source establishes a skill, remove it from the listed stack even if it is in the target advert.
- Keep the exact meaning of sensitive terms such as billing versus payment processing, risk review versus financial-crime investigations, and internal tooling versus customer-facing products.
- If a job bank contains ongoing training or enrolled degree, label it ongoing. Do not list it as graduated.
- When a claim has an explicit numeric metric, double-check time window, baseline, units and causal link. If not known, qualify or omit the calculation.
- Avoid misattributing company-wide customer counts, transaction volume, total assets, or market share to an individual candidate's project.
- Use British or US English consistently; preserve official organization and technology spellings.

## Triage when there is weak coverage

If the job has hard requirements missing from the bank, surface them honestly in the audit and lean on related skills without claiming the missing tool. A weaker truthful CV is preferable to a more impressive fabricated one. If a missing metric would materially improve the CV, ask whether the user can verify it and offer a version with qualitative impact meanwhile.
