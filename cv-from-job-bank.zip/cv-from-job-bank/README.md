# CV from Job Bank — Claude Skill

A portable custom Claude skill that creates truthful, Germany-oriented, role-specific CVs from a **Job Bank + job advertisement**. It is inspired by the working principles in the user's CV guide, with original instructions and evidence controls.

## Install in Claude (web / desktop)

1. Upload the provided `cv-from-job-bank.zip` in **Customize → Skills → Add / Upload skill** (menu labels may vary by Claude product).
2. Enable the skill.
3. In a chat, upload or paste **your Job Bank** and the **job advertisement**. Include your existing CV if available.
4. Say: "Use cv-from-job-bank to create a tailored CV for this role. English, German market, ATS-first. Show the evidence audit and don't invent metrics."

The package deliberately **does not include your actual job bank**. Keep your master bank separately and supply it when you want a CV. This prevents accidental redistribution of personal material and allows you to update it independently.

## Install in Claude Code

Copy the `cv-from-job-bank` folder into either:

- `~/.claude/skills/cv-from-job-bank/` for personal use across projects, or
- `.claude/skills/cv-from-job-bank/` within one project.

Then ask Claude to use `/cv-from-job-bank` with a job ad and the accessible bank files. The same `SKILL.md` works in Claude chat and Claude Code.

## Input checklist

- [ ] Job Bank / achievement inventory (required)
- [ ] Target job ad (required)
- [ ] Existing CV (optional)
- [ ] Output preference: guide-inspired two-column or ATS-first one-column (optional)
- [ ] Language preference; English is the default (optional)

If the bank is missing, Claude should **request it**, not pretend it knows your work history.

## Expected behavior

The skill first matches the vacancy's key requirements to source-backed achievements. It then rewrites and ranks bullets, emphasizes evidence from the most relevant positions, prepares the CV, and produces a compact claim audit. It will ask for confirmation when an important outcome or metric is ambiguous.

## What it does not do

- Invent the metrics or duties that would make you appear to match a vacancy.
- Treat the vacancy as proof that you have used its technology.
- Modify your Job Bank automatically.
- Reproduce the paid CV guide's proprietary visual template or sample CV.

## Fast test after installation

Give Claude a short sample bank with a verified Node.js API project but **no AWS or Kubernetes** and a vacancy requiring all three. The returned CV should describe Node.js, flag AWS/Kubernetes as gaps, and **not** silently add those skills. Then test with a real bank and check each figure and job title.
